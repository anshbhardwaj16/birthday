"use client";

import { useEffect, useId, useRef, useState, type CSSProperties } from "react";
import clsx from "clsx";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { Play, RotateCcw } from "lucide-react";
import { showEmptySlots, video } from "@/config/media";
import { announceMedia } from "@/lib/mediabus";
import { FilePath, Hint, MediaHeading, parseRatio } from "@/components/media/parts";
import styles from "@/components/media/media.module.css";

const ratio = parseRatio(video.ratio, 16 / 9);
const PART_EASE: [number, number, number, number] = [0.7, 0, 0.3, 1];

type FullscreenVideo = HTMLVideoElement & { webkitDisplayingFullscreen?: boolean };

export function VideoMessage() {
  const headingId = useId();
  const stageRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [open, setOpen] = useState(false);
  const [watched, setWatched] = useState(false);
  const reduce = useReducedMotion();
  const inView = useInView(stageRef, { amount: 0.3 });

  // Scrolling away pauses the video (but not while it's fullscreen).
  useEffect(() => {
    const element = videoRef.current as FullscreenVideo | null;
    if (inView || !element || document.fullscreenElement || element.webkitDisplayingFullscreen) return;
    element.pause();
  }, [inView]);

  // If the section unmounts mid-video, let the music come back.
  useEffect(() => {
    const element = videoRef.current;
    return () => {
      if (element && !element.paused) announceMedia(false);
    };
  }, []);

  if (!video.src && !showEmptySlots) return null;

  const start = () => {
    setOpen(true);
    const element = videoRef.current;
    if (!element) return;
    if (element.ended) element.currentTime = 0;
    // Called straight from the tap, so the browser allows sound.
    element.play().catch(() => {
      // Blocked or interrupted. The native controls are showing, so a second tap works.
    });
  };

  const curtain = (side: "left" | "right") => (
    <motion.span
      aria-hidden="true"
      className={clsx(styles.curtain, side === "left" ? styles.curtainLeft : styles.curtainRight)}
      initial={false}
      animate={{ x: open ? (side === "left" ? "-100%" : "100%") : "0%" }}
      transition={{ duration: reduce ? 0 : 1.15, ease: PART_EASE }}
    />
  );

  return (
    <section aria-labelledby={headingId} className={clsx(styles.vars, styles.band, styles.screening)}>
      <MediaHeading id={headingId} title={video.title} note={video.note} />

      <div
        ref={stageRef}
        className={styles.stage}
        style={{ "--ratio": ratio } as CSSProperties}
        data-portrait={ratio < 1}
      >
        {video.src ? (
          <video
            ref={videoRef}
            className={styles.video}
            src={video.src}
            poster={video.poster || undefined}
            preload="metadata"
            playsInline
            controls={open}
            aria-label={video.title}
            onPlay={() => announceMedia(true)}
            onPause={() => announceMedia(false)}
            onEnded={() => {
              setOpen(false);
              setWatched(true);
            }}
          >
            {video.captions ? (
              <track kind="captions" src={video.captions} srcLang="en" label="Captions" default />
            ) : null}
          </video>
        ) : open ? (
          <Leader onClose={() => setOpen(false)} />
        ) : null}

        {curtain("left")}
        {curtain("right")}

        {!open ? (
          <div className={styles.overlay}>
            <button type="button" className={styles.playButton} onClick={start}>
              {watched ? (
                <RotateCcw size={18} aria-hidden="true" />
              ) : (
                <Play size={18} aria-hidden="true" fill="currentColor" />
              )}
              {watched ? "Watch again" : "Play the video"}
            </button>
          </div>
        ) : null}
      </div>
    </section>
  );
}

/** Placeholder shown behind the curtains until a video is added. */
function Leader({ onClose }: { onClose: () => void }) {
  return (
    <button type="button" className={styles.leader} onClick={onClose} aria-label="Close the curtains">
      <span className={styles.dial} aria-hidden="true">
        <span className={styles.hand} />
        <span className={styles.digit} data-n="3">
          3
        </span>
        <span className={styles.digit} data-n="2">
          2
        </span>
        <span className={styles.digit} data-n="1">
          1
        </span>
      </span>
      <Hint>
        Add the video at <FilePath>public/media/video/message.mp4</FilePath>, then set <FilePath>video.src</FilePath> in{" "}
        <FilePath>src/config/media.ts</FilePath>
      </Hint>
    </button>
  );
}
