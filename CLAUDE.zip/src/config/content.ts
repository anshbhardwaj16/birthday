import { settings } from "./settings";

const { name, from } = settings;

/**
 * Everything the birthday person sees once the surprise is unlocked.
 *
 * This is SAMPLE COPY. Replace it with your own words, names and memories.
 *
 * Photos: drop images into `public/photos/` and set `image: "/photos/1.jpg"`.
 * Moments without an image get an illustrated placeholder.
 */
export const content = {
  tagline:
    "Another trip around the sun, and somehow you keep getting better at it.",

  letter: {
    greeting: `Dear ${name},`,
    paragraphs: [
      "I wanted to give you something that couldn't be bought in a hurry, so I built this instead. It took a while. You were worth every minute.",
      "People like to say that the best part of a friendship is the big moments. I think it's the small ones: the messages at odd hours, the jokes nobody else gets, the way you always notice when something's off.",
      "Whatever this year brings, I hope it's kind to you. And if it isn't, I hope you remember how many people are on your side.",
    ],
    signoff: "With all my love,",
  },

  /** Years are free text, so "Summer 2019" works too. */
  story: [
    {
      year: "2016",
      title: "The day we met",
      text: "You walked in late, borrowed a pen and never gave it back. I still haven't forgiven you.",
    },
    {
      year: "2018",
      title: "The trip that went off plan",
      text: "Wrong train, wrong city, best weekend of the year. We still tell it differently every time.",
    },
    {
      year: "2020",
      title: "The long calls",
      text: "When the world got small, you made it feel bigger. Hours on the phone, nothing and everything said.",
    },
    {
      year: "2023",
      title: "The big news",
      text: "I cried more than you did. Neither of us will admit it in front of anyone.",
    },
    {
      year: "Today",
      title: "Still here",
      text: "Older, a little wiser, exactly as ridiculous. Please never change.",
    },
  ],

  /** Add `image: "/photos/name.jpg"` to use a real photo. */
  moments: [
    { caption: "The trip that went completely off plan", tone: 0 },
    { caption: "Midnight snacks, again", tone: 1 },
    { caption: "That one perfect sunset", tone: 2 },
    { caption: "Matching outfits (zero regrets)", tone: 3 },
    { caption: "Your “I'm fine” face", tone: 4 },
    { caption: "Everyone we love in one frame", tone: 5 },
  ] as { caption: string; tone: number; image?: string }[],

  /** Keep each under about 70 characters so it fits on a sticker. */
  reasons: [
    "You make everyone feel like the main character.",
    "Your laugh arrives before the joke does.",
    "You remember the small things.",
    "You show up. Every time, no questions asked.",
    "Your playlists are dangerously good.",
    "You're braver than you give yourself credit for.",
    "You turn bad days into stories worth telling.",
    "You give great advice, then ignore it yourself.",
    "You're always up for one more adventure.",
    "Your kindness is never for show.",
    "You make quiet moments feel full.",
    "You are, quite simply, one of the good ones.",
  ],

  wishes: [
    {
      from: "Mum & Dad",
      note: "family",
      text: "Our favourite person since day one. We're so proud of who you've become.",
    },
    {
      from: "Priya",
      note: "best friend",
      text: "Thank you for every 2am conversation. Happy birthday to my person.",
    },
    {
      from: "Jordan",
      note: "teammate",
      text: "Best colleague, worst at keeping secrets. Have the day you deserve.",
    },
    {
      from: "Grandma",
      note: "family",
      text: "Eat the cake. Then eat a second slice. That's an order.",
    },
    {
      from: "Marcus",
      note: "old friend",
      text: "Another year older and I'm still not catching up. Happy birthday!",
    },
    {
      from: "Chloe",
      note: "neighbour",
      text: "You make the whole street brighter. Enjoy every minute today.",
    },
    {
      from: "Sam",
      note: "the one who built this",
      text: "Look at that. You made it to another year. Slightly alarming, mostly wonderful.",
    },
    {
      from: "The whole team",
      note: "everyone",
      text: "Cake is in the fridge. Do not tell anyone we told you.",
    },
  ],

  /** The scratch card. */
  gift: {
    title: "One dinner, your choice",
    text: "Any place, any city, any craving. I'll book it and I'll pay.",
    fine: `Redeem by telling ${from}. Valid all year, no take-backs.`,
  },

  footer: {
    title: `Happy birthday, ${name}.`,
    text: "Here's to the year ahead, and everyone who gets to share it with you.",
  },
};
