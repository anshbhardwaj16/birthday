/**
 * The essentials. Edit this file first.
 *
 * Everything else (letter, photos, reasons, messages, gift) lives in
 * `src/config/content.ts`.
 */
export const settings = {
  /** Who the birthday is for. Shown on the countdown and across the site. */
  name: "Alex",

  /** Who the site is from. Signs the letter and the footer. */
  from: "Sam",

  /**
   * The moment the surprise unlocks.
   *
   * Written WITHOUT an offset, it means "midnight in the opener's own timezone",
   * which is what you want for a birthday ("00:00 wherever you are").
   * To pin one exact instant for everyone, add an offset, e.g. "2026-11-15T00:00:00+05:30".
   */
  unlockAt: "2026-11-15T00:00:00",

  /** Their date of birth (YYYY-MM-DD). Drives the age, star sign and "by the numbers". */
  birthDate: "2000-11-15",

  /** One-liners that rotate under the countdown. Keep them free of spoilers. */
  teasers: [
    "It isn't socks.",
    "Slightly dramatic. Entirely worth it.",
    "Somebody has been planning this for weeks.",
    "Good things take their sweet time.",
    "Changing your clock won't speed it up.",
  ],

  /**
   * Preview links, handy while you build. Set to false before you share the site.
   *   ?demo=20   run the whole countdown and unwrapping in 20 seconds
   *   ?open      skip the wait and show the "unwrap" button
   *   ?site      jump straight to the unlocked site
   */
  allowPreviewLinks: true,
} as const;
